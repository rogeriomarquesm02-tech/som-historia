# Som & História 1.9 — gerar APK

## Android Studio (recomendado)
1. Abra a pasta `android/` no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Selecione `app`.
4. Use **Build > Generate App Bundle(s) / APK(s) > Generate APK(s)**.
5. O APK de debug ficará em `android/app/build/outputs/apk/debug/`.

## Terminal
O projeto contém `gradlew` como lançador. Este ambiente não inclui o Gradle Wrapper JAR nem o Android SDK, portanto o APK não é compilado aqui.
Com Gradle instalado:

```bash
cd android
./gradlew assembleDebug
```

## Configuração do servidor
No aplicativo, use **Configurar servidor** e informe a URL HTTPS pública da API.
Não coloque `MUREKA_API_KEY` ou `MP_ACCESS_TOKEN` dentro do APK.
