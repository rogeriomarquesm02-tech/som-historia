# Som & História — Protótipo 1.8

## O que esta versão corrige
- Backend e Android agora exibem versão **1.8** de forma consistente.
- Corrigidos os nomes das variáveis do Mercado Pago no `.env.production.example`: `MP_ACCESS_TOKEN` e `MP_WEBHOOK_SECRET`, que são exatamente os nomes lidos pelo servidor.
- Adicionado `server/.gitignore` para evitar envio acidental de `.env`, `node_modules` e dados de pedidos.
- Adicionado `server/smoke-test.mjs` para validar a inicialização da API e o endpoint `/health` sem precisar das chaves reais.
- Android atualizado para `versionCode 9` / `versionName 1.8`.

## Fluxo comercial
1. Cliente informa nome, história, relação, gênero, clima e formação vocal.
2. O servidor pede somente a letra à Mureka.
3. Cliente revisa a prévia.
4. Cliente paga **1 música** via Pix/Mercado Pago.
5. Mercado Pago confirma por consulta/Webhook.
6. Somente depois do pagamento aprovado, o servidor pede **2 versões** à Mureka.
7. O app acompanha a geração e permite ouvir, baixar e compartilhar.

## Configuração do servidor
Use `server/.env.production.example` como base e configure:
- `MUREKA_API_KEY`
- `MP_ACCESS_TOKEN`
- `MP_WEBHOOK_SECRET`
- `PUBLIC_BASE_URL`
- `CORS_ORIGIN`
- `PRICE`

Nunca coloque essas chaves no APK nem envie pelo chat.

## Teste local da API
Dentro de `server/`:
```bash
npm install
node smoke-test.mjs
```

O smoke test não gera música nem cobra pagamento. Ele apenas sobe a API isoladamente, verifica `/health` e confirma o comportamento quando a chave Mureka não está configurada.

## Publicação
O `docker-compose.yml` usa Caddy para HTTPS. Aponte o DNS para o servidor, configure o `.env`, monte armazenamento persistente em `/app/data` e então execute `docker compose up -d --build`.

No Android, em **Configurar servidor**, informe a URL HTTPS pública, por exemplo `https://api.seudominio.com`.

## Limitação atual
Este pacote continua sendo **código-fonte**. Não há APK assinado dentro dele. O próximo passo de publicação é executar o build Android em um ambiente com Android SDK/Gradle e configurar a assinatura da aplicação.
