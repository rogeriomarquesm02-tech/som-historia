import { spawn } from 'node:child_process';
import { once } from 'node:events';

const port = 3197;
const child = spawn(process.execPath, ['server.js'], {
  cwd: new URL('.', import.meta.url).pathname,
  env: { ...process.env, PORT: String(port), NODE_ENV: 'test', ORDERS_FILE: './data/test-orders.json', DRAFTS_FILE: './data/test-drafts.json' },
  stdio: ['ignore', 'pipe', 'pipe']
});
let output = '';
child.stdout.on('data', d => output += d);
child.stderr.on('data', d => output += d);

try {
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('Servidor não iniciou em 5s')), 5000);
    const check = setInterval(() => {
      if (output.includes('server 1.9 em 3197') || output.includes('EADDRINUSE')) { clearInterval(check); clearTimeout(timer); resolve(); }
    }, 50);
    child.once('exit', code => reject(new Error(`Servidor encerrou antes do teste: ${code}\n${output}`)));
  });
  const health = await fetch(`http://127.0.0.1:${port}/health`);
  const data = await health.json();
  if (!health.ok || data.ok !== true || data.version !== '1.9') throw new Error('Health check falhou');

  const missingLyrics = await fetch(`http://127.0.0.1:${port}/api/lyrics`, { method: 'POST', headers: {'content-type':'application/json'}, body: '{}' });
  if (missingLyrics.status !== 500) throw new Error(`Validação de credencial inesperada: ${missingLyrics.status}`);

  console.log('SMOKE TEST OK:', { health: data.ok, version: data.version, missingCredentials: missingLyrics.status });
} finally {
  child.kill('SIGTERM');
  await once(child, 'exit').catch(() => {});
}
