import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import crypto from "crypto";
import fs from "fs";
dotenv.config();
const app=express();
const isProduction=process.env.NODE_ENV === "production";
const allowedOrigin=process.env.CORS_ORIGIN||"*";
app.use(cors({origin:allowedOrigin === "*" ? true : allowedOrigin}));
app.use(express.json({limit:"128kb"}));
app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use((req,res,next)=>{
  res.setHeader("X-Content-Type-Options","nosniff");
  res.setHeader("X-Frame-Options","DENY");
  res.setHeader("Referrer-Policy","no-referrer");
  if(isProduction) res.setHeader("Strict-Transport-Security","max-age=31536000; includeSubDomains");
  next();
});
const key=process.env.MUREKA_API_KEY;
const mp=process.env.MP_ACCESS_TOKEN;
const BASE="https://api.mureka.ai";
const headers={"Authorization":`Bearer ${key}`,"Content-Type":"application/json"};
const MP_API="https://api.mercadopago.com";
const publicBase=process.env.PUBLIC_BASE_URL||"";
const webhookSecret=process.env.MP_WEBHOOK_SECRET||"";
const ORDERS_FILE=process.env.ORDERS_FILE||"./data/orders.json";
const DRAFTS_FILE=process.env.DRAFTS_FILE||"./data/drafts.json";
const orders=new Map();
const drafts=new Map();

function loadMap(file,map){try{if(!fs.existsSync(file))return;const raw=JSON.parse(fs.readFileSync(file,"utf8"));for(const [id,v] of Object.entries(raw))map.set(id,v)}catch(e){console.error("Falha ao carregar",file,e.message)}}
function saveMap(file,map){try{fs.mkdirSync(requireDir(file),{recursive:true});fs.writeFileSync(file,JSON.stringify(Object.fromEntries(map),null,2))}catch(e){console.error("Falha ao salvar",file,e.message)}}
function requireDir(file){return file.includes("/") ? file.slice(0,file.lastIndexOf("/")) : "."}
loadMap(ORDERS_FILE,orders); loadMap(DRAFTS_FILE,drafts);
function saveOrders(){saveMap(ORDERS_FILE,orders)}
function saveDrafts(){saveMap(DRAFTS_FILE,drafts)}

app.get("/health",(req,res)=>res.json({
  ok:true,
  service:"Som & História",
  version:"1.9",
  environment:process.env.NODE_ENV||"development",
  murekaConfigured:Boolean(key),
  mercadoPagoConfigured:Boolean(mp),
  publicBaseConfigured:Boolean(publicBase),
  webhookConfigured:Boolean(webhookSecret),
  timestamp:new Date().toISOString()
}));

// 0.9: primeiro criamos somente a letra/rascunho. A geração de áudio fica para depois do pagamento.
app.post("/api/lyrics",async(req,res)=>{
  try{
    if(!key)return res.status(500).json({error:"MUREKA_API_KEY não configurada."});
    const {name,story,relation="alguém especial",mood="Romântico",genre="Pagode"}=req.body;
    if(!name||!story)return res.status(400).json({error:"Nome e história são obrigatórios."});
    const prompt=`Escreva uma letra de música em português do Brasil, personalizada para ${name}, dedicada a ${relation}. História: ${story}. Estilo: ${genre}. Clima: ${mood}. Crie estrutura com [Verse], [Pre-Chorus], [Chorus], [Bridge] e [Outro]. Não invente fatos que não estejam na história. A letra deve ser emocionante, cantável e original.`;
    const r=await fetch(`${BASE}/v1/lyrics/generate`,{method:"POST",headers,body:JSON.stringify({prompt})});
    const d=await r.json(); if(!r.ok)return res.status(r.status).json(d);
    const draftId=crypto.randomUUID();
    const lyrics=d.lyrics||d.content||"";
    drafts.set(draftId,{draftId,name,story,relation,mood,genre,lyrics,createdAt:new Date().toISOString(),paid:false});
    saveDrafts();
    res.json({draftId,lyrics,title:d.title||"Som & História"});
  }catch(e){res.status(500).json({error:e.message})}
});

// Gera as 2 músicas somente se houver um pagamento aprovado para o rascunho.
app.post("/api/generate",async(req,res)=>{
  try{
    if(!key)return res.status(500).json({error:"MUREKA_API_KEY não configurada."});
    const {draftId,singer="Homem"}=req.body;
    const draft=drafts.get(draftId);
    if(!draft)return res.status(404).json({error:"Rascunho não encontrado."});
    const paidOrder=[...orders.values()].find(o=>o.generationId===draftId&&o.paid===true);
    if(!paidOrder)return res.status(402).json({error:"Pagamento ainda não aprovado."});
    if(draft.taskId)return res.json({id:draft.taskId,status:"queued"});
    const prompt=`${draft.genre}, Brazilian, ${draft.mood}, personalized song, ${singer.toLowerCase()} vocal, two clearly different melodies, polished arrangement, version A and version B should not sound alike`;
    const gender=singer.toLowerCase().includes("mulher")&&!singer.toLowerCase().includes("homem")?"female":"male";
    const sr=await fetch(`${BASE}/v1/song/generate`,{method:"POST",headers,body:JSON.stringify({lyrics:draft.lyrics,model:"auto",n:2,prompt,gender,stream:false})});
    const sd=await sr.json();
    if(sr.ok&&sd.id){draft.taskId=sd.id;draft.generatedAt=new Date().toISOString();saveDrafts()}
    res.status(sr.status).json({...sd,title:"Som & História",lyrics:draft.lyrics});
  }catch(e){res.status(500).json({error:e.message})}
});

app.get("/api/generate/:id",async(req,res)=>{
  try{
    if(!key)return res.status(500).json({error:"MUREKA_API_KEY não configurada."});
    const r=await fetch(`${BASE}/v1/song/query/${encodeURIComponent(req.params.id)}`,{headers:{"Authorization":`Bearer ${key}`}});
    res.status(r.status).json(await r.json());
  }catch(e){res.status(500).json({error:e.message})}
});

app.post("/api/payment/create",async(req,res)=>{
  try{
    if(!mp)return res.status(500).json({error:"MP_ACCESS_TOKEN não configurado."});
    const {generationId,email,amount=Number(process.env.PRICE||49.90),clientRequestId}=req.body;
    const cleanEmail=String(email||"").trim().toLowerCase();
    const price=Number(amount);
    if(!generationId||!cleanEmail)return res.status(400).json({error:"generationId e email são obrigatórios."});
    if(!Number.isFinite(price)||price<=0||price>9999)return res.status(400).json({error:"Valor de pagamento inválido."});
    if(isProduction && (!publicBase || !publicBase.startsWith("https://")))return res.status(500).json({error:"PUBLIC_BASE_URL HTTPS é obrigatória em produção."});
    if(clientRequestId){const existing=[...orders.values()].find(o=>o.clientRequestId===clientRequestId);if(existing)return res.json({orderId:existing.orderId,paymentId:existing.paymentId,status:existing.status,qr_code:existing.qr_code,qr_code_base64:existing.qr_code_base64,ticket_url:existing.ticket_url,reused:true});}
    if(!drafts.has(generationId))return res.status(404).json({error:"Rascunho não encontrado."});
    const orderId=crypto.randomUUID();
    const body={transaction_amount:price,description:"Som & História — 2 versões da música",payment_method_id:"pix",external_reference:orderId,payer:{email:cleanEmail}};
    if(publicBase)body.notification_url=`${publicBase.replace(/\/$/,"")}/api/payment/webhook`;
    const r=await fetch(`${MP_API}/v1/payments`,{method:"POST",headers:{"Authorization":`Bearer ${mp}`,"Content-Type":"application/json","X-Idempotency-Key":crypto.randomUUID()},body:JSON.stringify(body)});
    const d=await r.json(); if(!r.ok)return res.status(r.status).json(d);
    orders.set(orderId,{orderId,generationId,email,paymentId:String(d.id),status:d.status||"pending",paid:false,clientRequestId:clientRequestId||null,qr_code:d.point_of_interaction?.transaction_data?.qr_code||"",qr_code_base64:d.point_of_interaction?.transaction_data?.qr_code_base64||"",ticket_url:d.point_of_interaction?.transaction_data?.ticket_url||"",createdAt:new Date().toISOString()});
    saveOrders();
    res.json({orderId,paymentId:d.id,status:d.status,qr_code:d.point_of_interaction?.transaction_data?.qr_code,qr_code_base64:d.point_of_interaction?.transaction_data?.qr_code_base64,ticket_url:d.point_of_interaction?.transaction_data?.ticket_url});
  }catch(e){res.status(500).json({error:e.message})}
});

app.get("/api/payment/order/:orderId",async(req,res)=>{
  try{
    const order=orders.get(req.params.orderId); if(!order)return res.status(404).json({error:"Pedido não encontrado."});
    if(mp&&order.paymentId){
      const r=await fetch(`${MP_API}/v1/payments/${encodeURIComponent(order.paymentId)}`,{headers:{"Authorization":`Bearer ${mp}`}});
      if(r.ok){const d=await r.json();order.status=d.status||order.status;order.paid=d.status==="approved";order.status_detail=d.status_detail;order.updatedAt=new Date().toISOString();saveOrders();
        if(order.paid){const draft=drafts.get(order.generationId);if(draft){draft.paid=true;saveDrafts()}}
      }
    }
    res.json({orderId:order.orderId,generationId:order.generationId,paymentId:order.paymentId,status:order.status,paid:order.paid});
  }catch(e){res.status(500).json({error:e.message})}
});

function validWebhook(req){
  if(!webhookSecret)return true;
  const sig=req.get("x-signature")||"",requestId=req.get("x-request-id")||"";
  const parts=Object.fromEntries(sig.split(",").map(x=>x.split("=")).filter(x=>x.length===2));
  const ts=parts.ts,v1=parts.v1,dataId=String(req.query["data.id"]||req.body?.data?.id||"").toLowerCase();
  if(!ts||!v1||!dataId)return false;
  const manifest=`id:${dataId};request-id:${requestId};ts:${ts};`;
  const expected=crypto.createHmac("sha256",webhookSecret).update(manifest).digest("hex");
  try{return crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(v1))}catch{return false}
}
app.post("/api/payment/webhook",async(req,res)=>{
  try{
    if(!validWebhook(req))return res.sendStatus(401);
    const paymentId=req.body?.data?.id||req.query["data.id"]||req.body?.id;
    if(mp&&paymentId){const r=await fetch(`${MP_API}/v1/payments/${encodeURIComponent(paymentId)}`,{headers:{"Authorization":`Bearer ${mp}`}});if(r.ok){const d=await r.json(),ref=d.external_reference;if(ref&&orders.has(ref)){const o=orders.get(ref);o.status=d.status;o.paid=d.status==="approved";o.status_detail=d.status_detail;o.updatedAt=new Date().toISOString();saveOrders();if(o.paid){const draft=drafts.get(o.generationId);if(draft){draft.paid=true;saveDrafts()}}}}}
  }catch(e){console.error("Webhook Mercado Pago:",e.message)}
  res.sendStatus(200);
});

const port=Number(process.env.PORT||3000);
const server=app.listen(port,()=>console.log(`Som Som & História server 1.7 História server 1.9 em ${port}`));
function shutdown(signal){console.log(`Recebido ${signal}; encerrando...`);server.close(()=>process.exit(0));setTimeout(()=>process.exit(1),10000).unref()}
process.on("SIGTERM",()=>shutdown("SIGTERM"));
process.on("SIGINT",()=>shutdown("SIGINT"));
