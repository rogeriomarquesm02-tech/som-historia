# Gerar o APK sem computador

Este projeto inclui um GitHub Actions que compila o APK na nuvem. Você pode fazer tudo pelo navegador do celular.

1. Crie uma conta no GitHub, se ainda não tiver.
2. Crie um repositório novo.
3. Envie todos os arquivos desta pasta para o repositório, mantendo as pastas.
4. Abra a aba **Actions**.
5. Selecione **Build Som & História APK**.
6. Toque em **Run workflow**.
7. Quando terminar com sucesso, abra a execução e baixe o artefato **SomHistoria-debug-apk**.
8. Dentro dele estará o `app-debug.apk` para instalar no Android.

O workflow não contém nenhuma chave Mureka ou Mercado Pago. Não coloque essas chaves no repositório público.
