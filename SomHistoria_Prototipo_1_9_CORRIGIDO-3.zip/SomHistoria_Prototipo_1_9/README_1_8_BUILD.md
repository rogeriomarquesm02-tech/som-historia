# Som & História 1.8 — build Android

Esta versão organiza o projeto para importação no Android Studio e inclui a configuração do Gradle Wrapper para Gradle 8.10.2.

## Gerar APK no Android Studio
1. Abra a pasta `android/` no Android Studio.
2. Aguarde o Gradle Sync.
3. Se o Android Studio pedir para instalar SDK 35 ou componentes, aceite.
4. Use **Build > Build APK(s)**.
5. O APK de debug normalmente será criado em `android/app/build/outputs/apk/debug/app-debug.apk`.

## Observação importante
Este ambiente não possui Android SDK/Gradle instalado, portanto não foi possível compilar o APK aqui. Não há alegação de APK já compilado.

## Servidor
O backend continua em `server/`. Para uso real, configure as variáveis do `.env.production` e publique atrás de HTTPS. Nunca coloque chaves Mureka ou Mercado Pago dentro do APK.
