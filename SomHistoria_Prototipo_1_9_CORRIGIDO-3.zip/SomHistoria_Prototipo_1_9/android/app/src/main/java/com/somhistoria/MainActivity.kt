package com.somhistoria

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.speech.RecognizerIntent
import android.widget.*
import android.graphics.BitmapFactory
import android.util.Base64
import android.media.MediaPlayer
import android.content.SharedPreferences
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var nome: EditText
    private lateinit var historia: EditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private val defaultServer = "http://10.0.2.2:3000"
    private lateinit var prefs: SharedPreferences
    private val server: String get() = prefs.getString("server_url", defaultServer)?.trimEnd('/') ?: defaultServer
    private val paymentUrl = "https://mpago.la/1mrsdG2"
    private var player: MediaPlayer? = null
    private var generationId: String = ""
    private var orderId: String = ""
    private var paid: Boolean = false
    private var lastResult: JSONObject? = null
    private var draftId: String = ""
    private var previewLyrics: String = ""
    private var selectedSinger: String = "Homem"
    private var selectedGenre: String = "Pagode"
    private var selectedMood: String = "Romântico"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("som_historia", Context.MODE_PRIVATE)
        telaInicial()
    }

    private fun telaInicial() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,28,28,28) }
        l.addView(TextView(this).apply { text = "Som & História 🎵"; textSize = 30f })
        l.addView(Button(this).apply {
            text = "⚙️ Configurar servidor"
            setOnClickListener { configurarServidor() }
        })
        l.addView(Button(this).apply {
            text = "🧪 Testar conexão com servidor"
            setOnClickListener { testarServidor() }
        })
        l.addView(TextView(this).apply {
            text = "Servidor atual: $server"; textSize = 12f
        })
        l.addView(TextView(this).apply { text = "Sua história vira música. Paga 1 • recebe 2 versões."; textSize = 17f; setPadding(0,0,0,18) })
        nome = EditText(this).apply { hint = "Nome da pessoa"; singleLine = true }; l.addView(nome)
        historia = EditText(this).apply { hint = "Conte a história, momentos e sentimentos..."; minLines = 5; gravity = android.view.Gravity.TOP }; l.addView(historia)
        l.addView(Button(this).apply { text = "🎙️ Falar história"; setOnClickListener { fala() } })
        l.addView(TextView(this).apply { text = "Para quem é?"; textSize = 15f; setPadding(0,12,0,0) })
        val rel = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("Filho","Filha","Neto","Neta","Amigo","Amiga","Namorada","Esposa","Marido","Mãe","Avô","Avó","Alguém especial")) }; l.addView(rel)
        l.addView(TextView(this).apply { text = "Estilo musical"; textSize = 15f; setPadding(0,12,0,0) })
        val gen = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("Pagode","Hip hop","Reggae","Bossa nova","Forró","Tema de novela","Música infantil")) }; l.addView(gen)
        l.addView(TextView(this).apply { text = "Formação vocal"; textSize = 15f; setPadding(0,12,0,0) })
        val voice = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Homem","Mulher","Dupla homem + mulher","Duas mulheres","Dois homens")) }; l.addView(voice)
        l.addView(TextView(this).apply { text = "Clima da música"; textSize = 15f; setPadding(0,12,0,0) })
        val mood = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Romântico","Emocionante","Alegre","Saudade","Homenagem","Animado")) }; l.addView(mood)
        l.addView(TextView(this).apply { text = "💰 R$ 49,90 • pagamento antes da geração das 2 versões"; textSize = 15f; setPadding(0,18,0,8) })
        l.addView(Button(this).apply { text = "CRIAR PRÉVIA DA LETRA 🎵"; setOnClickListener {
            selectedGenre = gen.selectedItem.toString(); selectedMood = mood.selectedItem.toString()
            gerar(rel.selectedItem.toString(), selectedGenre, voice.selectedItem.toString(), selectedMood)
        } })
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = 0 }; l.addView(progress)
        status = TextView(this).apply { text = "Pronto para começar."; setPadding(0,8,0,0) }; l.addView(status)
        scroll.addView(l); root.addView(scroll, LinearLayout.LayoutParams(-1,-1)); setContentView(root)
    }


    private fun testarServidor() {
        Toast.makeText(this, "Testando conexão...", Toast.LENGTH_SHORT).show()
        thread {
            try {
                val out = JSONObject(get("$server/health"))
                val ok = out.optBoolean("ok")
                val msg = if (ok) "Servidor conectado • API ${out.optString("version", "?")}" else "Servidor respondeu, mas não confirmou OK."
                runOnUiThread { Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Não foi possível conectar: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun configurarServidor() {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,28,28,28) }
        l.addView(TextView(this).apply { text = "Configuração da API"; textSize = 26f })
        l.addView(TextView(this).apply { text = "No emulador Android, use http://10.0.2.2:3000. Em um celular real, use o endereço HTTPS público do servidor."; setPadding(0,8,0,12) })
        val input = EditText(this).apply { hint = "https://api.seudominio.com"; setText(server); singleLine = true }
        l.addView(input)
        l.addView(Button(this).apply {
            text = "Salvar endereço"
            setOnClickListener {
                val value = input.text.toString().trim().trimEnd('/')
                if (value.isBlank() || !(value.startsWith("http://") || value.startsWith("https://"))) {
                    Toast.makeText(this@MainActivity, "Informe um endereço começando por http:// ou https://", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                prefs.edit().putString("server_url", value).apply()
                Toast.makeText(this@MainActivity, "Servidor salvo.", Toast.LENGTH_SHORT).show()
                telaInicial()
            }
        })
        l.addView(Button(this).apply { text = "Usar servidor local do emulador"; setOnClickListener { prefs.edit().putString("server_url", defaultServer).apply(); telaInicial() } })
        l.addView(Button(this).apply { text = "← Voltar"; setOnClickListener { telaInicial() } })
        setContentView(l)
    }

    private fun fala() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Conte a história...")
        startActivityForResult(i, 9)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 9 && resultCode == RESULT_OK) {
            historia.setText(data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: "")
        }
    }

    private fun gerar(relacao: String, genero: String, voz: String, clima: String) {
        if (nome.text.isBlank() || historia.text.isBlank()) { status.text = "Preencha nome e história."; return }
        selectedSinger = voz
        progress.progress = 10; status.text = "Criando a prévia da letra..."
        thread {
            try {
                val body = JSONObject().apply {
                    put("name", nome.text.toString()); put("story", historia.text.toString())
                    put("relation", relacao); put("genre", genero); put("mood", clima)
                }
                val out = JSONObject(post("$server/api/lyrics", body))
                draftId = out.optString("draftId")
                previewLyrics = out.optString("lyrics")
                if (draftId.isBlank() || previewLyrics.isBlank()) throw Exception(out.optString("error", "Não foi possível criar a letra."))
                runOnUiThread { progress.progress = 25; status.text = "Prévia pronta. Confira a letra antes de pagar."; mostrarPrevia(out, relacao, genero, clima) }
            } catch (e: Exception) { runOnUiThread { status.text = "Erro: ${e.message}" } }
        }
    }

    private fun mostrarPrevia(out: JSONObject, relacao: String, genero: String, clima: String) {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,28,28,28) }
        l.addView(TextView(this).apply { text = "Prévia da sua música 🎵"; textSize = 27f })
        l.addView(TextView(this).apply { text = "Confira a letra. Depois do pagamento, geraremos as 2 versões musicais."; textSize = 16f })
        val preview = TextView(this).apply { text = previewLyrics; textSize = 16f; setPadding(0,18,0,18) }
        val scroll = ScrollView(this); scroll.addView(preview); l.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        l.addView(Button(this).apply { text = "💳 PAGAR 1 E RECEBER 2 VERSÕES"; setOnClickListener { pagamento() } })
        l.addView(Button(this).apply { text = "✏️ Alterar história"; setOnClickListener { telaInicial() } })
        setContentView(l)
    }

    private fun poll(id: String) {
        thread {
            var done = false
            while (!done) {
                try {
                    val o = JSONObject(get("$server/api/generate/$id"))
                    val st = o.optString("status")
                    val p = when (st) { "preparing" -> 25; "queued" -> 35; "running" -> 60; "streaming" -> 80; "succeeded" -> 100; else -> 15 }
                    runOnUiThread { progress.progress = p; status.text = "Status: $st" }
                    if (st == "succeeded") { done = true; runOnUiThread { generationId = id; resultado(o, id) } }
                    else if (st in listOf("failed", "timeouted", "cancelled")) { done = true; runOnUiThread { status.text = "A geração terminou com erro: ${o.optString("failed_reason", st)}" } }
                    else Thread.sleep(4000)
                } catch (e: Exception) { done = true; runOnUiThread { status.text = "Falha: ${e.message}" } }
            }
        }
    }

    private fun resultado(o: JSONObject, id: String) {
        lastResult = o
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,28,28,28) }
        l.addView(TextView(this).apply { text = "Sua história virou música! 🎉\nPaga 1 • recebe 2 versões"; textSize = 24f })
        l.addView(TextView(this).apply { text = "As duas versões ficam liberadas após a confirmação do pagamento." })
        val choices = o.optJSONArray("choices")
        if (choices != null) for (i in 0 until choices.length()) {
            val c = choices.getJSONObject(i)
            val url = c.optString("url", c.optString("audio_url", c.optString("stream_url", "")))
            l.addView(Button(this).apply {
                text = "▶ Tocar versão ${i + 1}"
                setOnClickListener {
                    if (!paid) Toast.makeText(this@MainActivity, "Faça o pagamento para liberar a versão completa.", Toast.LENGTH_SHORT).show()
                    else if (url.isNotBlank()) tocar(url) else Toast.makeText(this@MainActivity, "Áudio sem URL na resposta.", Toast.LENGTH_SHORT).show()
                }
            })
            l.addView(Button(this).apply {
                text = "⬇ Salvar versão ${i + 1} no celular"
                setOnClickListener {
                    if (!paid) Toast.makeText(this@MainActivity, "Faça o pagamento para liberar o download.", Toast.LENGTH_SHORT).show()
                    else if (url.isNotBlank()) baixar(url, "Som_Historia_Versao_${i + 1}.mp3") else Toast.makeText(this@MainActivity, "Áudio sem URL para baixar.", Toast.LENGTH_SHORT).show()
                }
            })
            l.addView(Button(this).apply {
                text = "📲 Compartilhar versão ${i + 1}"
                setOnClickListener {
                    if (!paid) Toast.makeText(this@MainActivity, "Faça o pagamento para liberar o compartilhamento.", Toast.LENGTH_SHORT).show()
                    else if (url.isNotBlank()) compartilhar(url, i + 1) else Toast.makeText(this@MainActivity, "Áudio sem URL para compartilhar.", Toast.LENGTH_SHORT).show()
                }
            })
        }
        l.addView(Button(this).apply { text = "💳 Pagar e liberar as 2 versões"; setOnClickListener { pagamento() } })
        l.addView(Button(this).apply { text = "Criar outra música"; setOnClickListener { telaInicial() } })
        setContentView(l)
    }


    private fun tocar(url: String) {
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(url)
                setOnPreparedListener { it.start(); Toast.makeText(this@MainActivity, "Reproduzindo...", Toast.LENGTH_SHORT).show() }
                setOnCompletionListener { it.release(); player = null }
                setOnErrorListener { _, _, _ -> Toast.makeText(this@MainActivity, "Não foi possível reproduzir este áudio.", Toast.LENGTH_SHORT).show(); true }
                prepareAsync()
            }
        } catch (e: Exception) { Toast.makeText(this, "Erro ao tocar: ${e.message}", Toast.LENGTH_SHORT).show() }
    }

    private fun baixar(url: String, nomeArquivo: String) {
        try {
            val req = DownloadManager.Request(Uri.parse(url))
                .setTitle("Som & História")
                .setDescription("Baixando $nomeArquivo")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, nomeArquivo)
            (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            Toast.makeText(this, "Download iniciado. Veja a pasta Downloads.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) { Toast.makeText(this, "Erro no download: ${e.message}", Toast.LENGTH_SHORT).show() }
    }

    private fun compartilhar(url: String, versao: Int) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "Ouça a versão $versao da minha música criada no Som & História: $url")
        }
        startActivity(Intent.createChooser(i, "Compartilhar música"))
    }

    private fun pagamento() {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,28,28,28) }
        l.addView(TextView(this).apply { text = "Pagar e gerar suas 2 músicas 🎵🎵"; textSize = 25f })
        l.addView(TextView(this).apply { text = "Você paga 1 música e recebe 2 versões com melodias diferentes. O áudio só é gerado após o pagamento aprovado." })
        val email = EditText(this).apply { hint = "Seu e-mail"; inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS }
        l.addView(email)
        val info = TextView(this).apply { text = ""; textSize = 15f }; l.addView(info)
        val pay = Button(this).apply {
            text = "💳 Gerar Pix Mercado Pago"
            setOnClickListener {
                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email.text.toString()).matches()) { info.text = "Digite um e-mail válido."; return@setOnClickListener }
                if (draftId.isBlank()) { info.text = "A prévia expirou. Crie a letra novamente."; return@setOnClickListener }
                isEnabled = false; info.text = "Criando cobrança Pix..."
                thread {
                    try {
                        val clientRequestId = "$draftId:${email.text.toString().trim().lowercase()}"
                        val body=JSONObject().apply{put("generationId",draftId);put("email",email.text.toString());put("amount",49.90);put("clientRequestId",clientRequestId)}
                        val out=JSONObject(post("$server/api/payment/create",body))
                        orderId=out.optString("orderId"); val qr=out.optString("qr_code"); val ticket=out.optString("ticket_url")
                        runOnUiThread {
                            info.text = if(qr.isNotBlank()) "Pix copia e cola:\n\n$qr\n\nAguardando pagamento..." else "Cobrança criada. Abra o Mercado Pago para pagar.\n\nAguardando pagamento..."
                            if(qr.isNotBlank()) l.addView(Button(this@MainActivity).apply {
                                text = "📋 Copiar Pix copia e cola"
                                setOnClickListener {
                                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                    cm.setPrimaryClip(android.content.ClipData.newPlainText("Pix Som & História", qr))
                                    Toast.makeText(this@MainActivity, "Pix copiado.", Toast.LENGTH_SHORT).show()
                                }
                            })
                            if(ticket.isNotBlank()) l.addView(Button(this@MainActivity).apply{text="🌐 Abrir pagamento";setOnClickListener{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(ticket)))}})
                        }
                        monitorarPagamento(info)
                    } catch(e:Exception){runOnUiThread{isEnabled=true;info.text="Erro ao criar pagamento: ${e.message}"}}
                }
            }
        }
        l.addView(pay)
        l.addView(Button(this).apply { text = "🌐 Link Mercado Pago (fallback)"; setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(paymentUrl))) } })
        l.addView(TextView(this).apply { text = "O link acima é apenas um fallback manual. A liberação automática usa o Pix criado pelo servidor." })
        l.addView(Button(this).apply { text = "← Voltar para a prévia"; setOnClickListener { mostrarPrevia(JSONObject().put("draftId",draftId),"","","") } })
        setContentView(l)
    }

    private fun monitorarPagamento(info: TextView) {
        if(orderId.isBlank()) return
        thread {
            repeat(100) {
                try {
                    val o=JSONObject(get("$server/api/payment/order/$orderId")); val st=o.optString("status")
                    if(o.optBoolean("paid") || st=="approved") {
                        paid=true
                        runOnUiThread { info.text="✅ Pagamento aprovado! Agora vamos gerar suas 2 versões..."; progress.progress=10; status=info; gerarAudiosDepoisDoPagamento() }
                        return@thread
                    }
                    runOnUiThread{info.text="Status do pagamento: $st\nAguardando confirmação..."}; Thread.sleep(3000)
                } catch(e:Exception) { runOnUiThread{info.text="Aguardando conexão com o servidor..."}; Thread.sleep(3000) }
            }
            runOnUiThread{info.text="Ainda não recebemos a confirmação. Você pode consultar novamente."}
        }
    }

    private fun gerarAudiosDepoisDoPagamento() {
        thread {
            try {
                val body=JSONObject().apply{put("draftId",draftId);put("singer",selectedSinger)}
                val o=JSONObject(post("$server/api/generate",body)); val id=o.optString("id",o.optString("task_id"))
                if(id.isBlank()) throw Exception(o.optString("error","A Mureka não retornou o task_id."))
                runOnUiThread { progress.progress=20; status.text="Pagamento confirmado. Gerando as 2 versões..." }
                poll(id)
            } catch(e:Exception){runOnUiThread{status.text="Erro ao iniciar as músicas: ${e.message}"}}
        }
    }

    private fun post(url: String, body: JSONObject): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val stream = if (c.responseCode >= 400) c.errorStream else c.inputStream
        return stream.bufferedReader().readText()
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection; c.requestMethod = "GET"
        val stream = if (c.responseCode >= 400) c.errorStream else c.inputStream
        return stream.bufferedReader().readText()
    }
}
